package day3Ex;
import java.util.Scanner;

public class Ques5 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		int numOfWords = str.split(" ").length;
		System.out.println(numOfWords);
	}
}

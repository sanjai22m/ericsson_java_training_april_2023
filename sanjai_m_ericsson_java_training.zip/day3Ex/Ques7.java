package day3Ex;

public class Ques7 {
	public static void main(String[] args) {
		String str = "bvrit college";
		String res = "";
		String[] arr = str.split("l");
		for(int i = 0; i < arr.length; i++) {
			if(i == 1) {
				res = res + arr[i] + "L";
			}
			else if(i == arr.length - 1) {
				res = res + arr[i];
			}
			else {
				res = res + arr[i] + "l";
			}
		}
		System.out.println(res);
	}
}

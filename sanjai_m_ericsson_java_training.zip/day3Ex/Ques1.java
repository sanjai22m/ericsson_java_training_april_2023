package day3Ex;
import java.util.Scanner;

public class Ques1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		int x = sc.nextInt();
		System.out.println(str.charAt(x));
	}
}

package day3Ex;
import java.util.Scanner;

public class Ques6 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		String res;
		for(int i = 0; i < str.length(); i++) {
			if(Character.isUpperCase(str.charAt(i))) {
				System.out.print(str.charAt(i));
			}
		}
	}
}

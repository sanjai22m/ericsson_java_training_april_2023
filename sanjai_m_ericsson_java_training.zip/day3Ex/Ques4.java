package day3Ex;
import java.util.Scanner;

public class Ques4 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		String match = sc.nextLine();
		if(str.endsWith(match)) {
			System.out.println("the string ends with the match");
		}
		else {
			System.out.println("the string does not end with the match");
		}
	}
}

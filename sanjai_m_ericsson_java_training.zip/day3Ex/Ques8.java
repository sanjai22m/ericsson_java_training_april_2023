package day3Ex;

public class Ques8 {
	public static void main(String[] args) {
		String str = "b.v.raju college";
		String res = "";
		String[] arr = str.split("raju");
		for(int i = 0; i < arr.length; i++) {
			if(i == 0) {
				res = res + arr[i] + "raju".toUpperCase();
			}
			else {
				res = res + arr[i];
			}
		}
		System.out.println(res);
	}
}

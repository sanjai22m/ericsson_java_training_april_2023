package day3Ex;
import java.util.Scanner;

public class Ques2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		String[] str_arr = str.split(" ");
		String res = "";
		for(String word : str_arr) {
			res = res + word.substring(0, 1).toUpperCase() + word.substring(1) + " ";
		}
		System.out.println(res);
	}
}

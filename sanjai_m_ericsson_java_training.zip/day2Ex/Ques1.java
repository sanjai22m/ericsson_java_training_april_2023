package day2Ex;

public class Ques1 {
	public static void main(String[] args) {
		int max = 200, a = 0, b = 1;
		while(a <= max) {
			System.out.print(a + ",");
			int c = a + b;
			a = b;
			b = c;
		}
	}
}

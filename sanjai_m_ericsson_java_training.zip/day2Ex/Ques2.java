package day2Ex;

class Vehicle {
	String color;
	String model;
	int wheels;
	int price;
	public void ride() {
		System.out.println("you are a riding a vehicle");
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public void getPrice() {
		System.out.println("The vehicle costs " + price);
	}
}

class Truck extends Vehicle {
	 String brand;
	 int loadCapacity = 2;
	 public void getLoad() {
		 System.out.println("This truck can carry " + loadCapacity + "tons");
	 }
}

class Car extends Vehicle {
	String brand;
	int seats = 5;
	public void getSeats() {
		System.out.println("This car has " + seats + "seats");
	}
}

class Bus extends Vehicle {
	String brand;
	int passengers = 40;
	public void getPassengers() {
		System.out.println("This bus can carry " + passengers + "passengers");
	}
}

// class Road -> Ques2
public class Ques2 {
	public static void main(String[] args) {
		Truck truck1 = new Truck();
		Car car1 = new Car();
		Bus bus1 = new Bus();
		
		truck1.color = "red";
		truck1.setPrice(500000);
		truck1.ride();
		truck1.getLoad();
		truck1.getPrice();
		System.out.println("\n");
		
		car1.color = "black";
		car1.setPrice(250000);
		car1.ride();
		car1.getPrice();
		System.out.println(car1.color);
		System.out.println("\n");
		
		bus1.brand = "volvo";
		bus1.ride();
		bus1.getPassengers();
		System.out.println(bus1.brand);
	}
}

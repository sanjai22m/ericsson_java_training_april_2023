package day4Ex;

import java.util.List;
import java.util.ArrayList;

public class CollectionDemo1{
	public static List<Integer> getZigZagList(List<Integer> list1, List<Integer> list2){
		List<Integer> res = new ArrayList<>();
		for(int i = 0; i < list1.size(); i++) {
			if(i % 2 == 0) {
				res.add(list1.get(i));
			}
			else {
				res.add(list2.get(i));
			}
		}
		return res;
	}
	public static void main(String[] args) {
		List<Integer> list1 = new ArrayList<>();
		list1.add(10);
		list1.add(20);
		list1.add(30);
		list1.add(40);
		list1.add(50);
		
		List<Integer> list2 = new ArrayList<>();
		list2.add(100);
		list2.add(200);
		list2.add(300);
		list2.add(400);
		list2.add(500);
		
		System.out.println(getZigZagList(list1, list2));
	}
}
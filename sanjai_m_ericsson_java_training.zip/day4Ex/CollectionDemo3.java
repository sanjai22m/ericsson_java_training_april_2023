package day4Ex;
import java.util.HashMap;

public class CollectionDemo3 {
	public static HashMap<String, String> getEntries(String[] arr){
		HashMap<String, String> hm = new HashMap<>();
		for(String str: arr) {
			hm.put(str.substring(0, 3).toUpperCase(), str);
		}
		return hm;
	}
	
	public static void main(String[] args) {
		String[] arr = {"goa", "kerala", "gujarat"};
		System.out.println(getEntries(arr));
	}
}

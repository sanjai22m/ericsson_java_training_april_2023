package day4Ex;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Collectiondemo2 {
	public static int getMaxNumber(List<Integer> list) {
		int max = list.get(0);
		for(int i: list) {
			if(i > max) {
				max = i;
			}
		}
		return max;
	}
	
	public static List<Integer> getReversedList(List<Integer> list){
		List<Integer> res = new ArrayList<>();
		for(int i = list.size() - 1; i > -1; i--) {
			res.add(list.get(i));
		}
		return res;
	}
	
	public static List<Integer> getOrderedList(List<Integer> list){
		Collections.sort(list);
		return list;
	}
	
	public static int getExactMidNumber(List<Integer> list) {
		Collections.sort(list);
		int n = list.size();
		if(n % 2 != 0) {
			return list.get(Math.floorDiv(n, 2));
		}
		else {
			return list.get(Math.max(Math.floorDiv(n, 2), Math.floorDiv(n, 2) - 1));
		}
	}
	
	public static void main(String[] args) {
		List<Integer> list = new ArrayList<Integer>();
		list.add(5);
		list.add(4);
		list.add(3);
		list.add(2);
		list.add(1);
		list.add(6);
		
		System.out.println(list); 
		System.out.println(getMaxNumber(list));
		System.out.println(getReversedList(list));
		System.out.println(getOrderedList(list));
		System.out.println(getExactMidNumber(list));
	}
}

package day1Ex;
import java.util.Scanner;

class Employee{
	String employeeName;
	String employeeId;
	String address;
	long contact;
	String gender;
}

public class Flow_control_ques_6 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Employee emp = new Employee();
		emp.employeeName = sc.nextLine();
		emp.employeeId = sc.nextLine();
		emp.address = sc.nextLine();
		emp.contact = sc.nextLong();
		sc.nextLine();
		emp.gender = sc.nextLine();
		System.out.println("Name: " + emp.employeeName + "\nID: " + emp.employeeId + "\nAddress: " + emp.address + "\nContact: " + emp.contact + "\nGender: " + emp.gender);
	}
}

package day1Ex;
import java.util.Scanner;

public class Flow_control_ques_2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		if((a < b) && (b < c)) {
			System.out.println(c + " is the greatest");
		}
		else if((a < b) && (c < b)) {
			System.out.println(b + " is the greatest");
		}
		else {
			System.out.println(a + " is the greatest");
		}
	}
}

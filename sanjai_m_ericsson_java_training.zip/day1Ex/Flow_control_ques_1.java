package day1Ex;
import java.util.Scanner;

public class Flow_control_ques_1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		if(x < 0) {
			System.out.println("number is negative");
		}
		else {
			System.out.println("number is positive");
		}
	}
}

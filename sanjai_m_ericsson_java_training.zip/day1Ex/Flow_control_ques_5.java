package day1Ex;
import java.util.Scanner;

public class Flow_control_ques_5 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int sum = 0;
		for(int i = 0; i < 5; i++) {
			int x = sc.nextInt();
			sum += x;
		}
		float avg = sum / 5;
		System.out.println("The sum is: " + sum);
		System.out.println("The average is: " + avg);
	}
}
